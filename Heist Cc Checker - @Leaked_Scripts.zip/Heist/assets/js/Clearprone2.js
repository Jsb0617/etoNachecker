function clearText22(){
document.getElementById("ccn_approved").innerHTML = "";
                     }