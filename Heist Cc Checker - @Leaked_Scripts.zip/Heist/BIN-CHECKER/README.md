# Bin-checker
BIN (BANK IDENTIFICATION NUMBER)
BIN stands for-BANK IDENTIFICATION NUMBER A BIN

is the starting 4 to 6 digits that appear on a credit/debit card. 

The BIN  uniquely identifies the institution/bank 

## Data
- [x] Type
- [x] Brand
- [x] Bank
- [x] Credit / Debit
- [x] Country

## Reboot13

[Telegram @reboot13](https://telegram.me/reboot13)

[Youtube- Krutik Raut](https://youtube.com/krutikraut)

